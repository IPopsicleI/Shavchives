
// Function to handle page navigation
function nextPage(path) {
    // Simulating the progression by directing to a different "page" (or adding more content)
    document.body.innerHTML = `
        <div class="content">
            <h1>You're on the ${path} path...</h1>
            <div class="images">
                <img src="images/${path}_image1.jpg" alt="Image 1" class="clickable" onclick="nextPage('${path}1')">
                <img src="images/${path}_image2.jpg" alt="Image 2" class="clickable" onclick="nextPage('${path}2')">
            </div>
        </div>
    `;
    applyStyles();
}

// Apply consistent styles
function applyStyles() {
    document.body.style.backgroundColor = 'black';
    document.body.style.color = 'red';
    document.body.style.fontFamily = "'Courier New', Courier, monospace";
}
